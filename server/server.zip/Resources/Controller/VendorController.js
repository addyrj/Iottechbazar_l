const slug =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6ImFudXJhZy5rdW1hci44ODA5OUBnbWFpbC5jb20iLCJpYXQiOjE3MTgxOTY5ODZ9.g-jgvVlShxeeKIU0h6jxC5WUTDZ7DfFwhIODWP7TVJI";
const email = "anurag.kumar.88099@gmail.com";
const address = "Iottech Software, Dwarka Sector 17";
const password = "U2FsdGVkX18g2XcRv+4AkfAn8dbXHpZyfJ6tYfa7oWM=";