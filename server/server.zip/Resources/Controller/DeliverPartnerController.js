res.status(200).send({
    status: 200,
    message: "Successfull",
    info: checkRole
})

